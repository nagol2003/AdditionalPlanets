package io.github.nagol2003.world;

public enum EnumOreGenProperties {

}
