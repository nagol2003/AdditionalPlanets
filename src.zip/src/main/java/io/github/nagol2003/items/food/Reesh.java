package io.github.nagol2003.items.food;

import net.minecraft.item.ItemFood;

public class Reesh extends ItemFood
{
	public Reesh(int amount, float saturation, boolean isWolfFood)
	{
		super(amount, saturation, isWolfFood);
	}

//	@Override
	//public void registerModels() {
	//	Main.proxy.registerItemRenderer(this, 0, "inventory");
	//}

}