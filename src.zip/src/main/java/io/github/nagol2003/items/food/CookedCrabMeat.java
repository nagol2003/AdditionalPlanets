package io.github.nagol2003.items.food;

import net.minecraft.item.ItemFood;

public class CookedCrabMeat extends ItemFood
{
	public CookedCrabMeat(int amount, float saturation, boolean isWolfFood)
	{
		super(amount, saturation, isWolfFood);
	}
}