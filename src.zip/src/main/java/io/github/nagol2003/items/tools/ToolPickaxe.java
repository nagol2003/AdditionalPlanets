package io.github.nagol2003.items.tools;

import net.minecraft.item.ItemPickaxe;

public class ToolPickaxe extends ItemPickaxe
{
	public ToolPickaxe(ToolMaterial material)
	{
		super(material);
	}
}