package io.github.nagol2003.items.tools;

import net.minecraft.item.ItemSword;

public class ToolSword extends ItemSword
{
	public ToolSword(ToolMaterial material)
	{
		super(material);
	}
}