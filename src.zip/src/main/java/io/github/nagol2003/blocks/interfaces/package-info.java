@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package io.github.nagol2003.blocks.interfaces;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;
