package io.github.nagol2003.celestial.planets.vulcan;

import net.minecraft.world.biome.BiomeDecorator;

public class BiomeDecoratorOther extends BiomeDecorator {

}
