package io.github.nagol2003.celestial.planets.kepler452b;

import net.minecraft.world.biome.BiomeDecorator;

public class BiomeDecoratorOther extends BiomeDecorator {

}
