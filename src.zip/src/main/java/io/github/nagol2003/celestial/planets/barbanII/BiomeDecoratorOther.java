package io.github.nagol2003.celestial.planets.barbanII;

import net.minecraft.world.biome.BiomeDecorator;

public class BiomeDecoratorOther extends BiomeDecorator {

}
