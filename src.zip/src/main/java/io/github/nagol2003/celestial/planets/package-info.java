@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package io.github.nagol2003.celestial.planets;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;
